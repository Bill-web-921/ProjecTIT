package com.example.budgetplanner;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText descriptionEditText, amountEditText;
    private Button addIncomeButton, addExpenseButton;
    private TextView balanceTextView;
    private RecyclerView recyclerView;

    private List<Transaction> transactions = new ArrayList<>();
    private TransactionAdapter adapter;
    private double balance = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        descriptionEditText = findViewById(R.id.descriptionEditText);
        amountEditText = findViewById(R.id.amountEditText);
        addIncomeButton = findViewById(R.id.addIncomeButton);
        addExpenseButton = findViewById(R.id.addExpenseButton);
        balanceTextView = findViewById(R.id.balanceTextView);
        recyclerView = findViewById(R.id.recyclerView);

        adapter = new TransactionAdapter(transactions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        addIncomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTransaction(true);
            }
        });

        addExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTransaction(false);
            }
        });
    }

    private void addTransaction(boolean isIncome) {
        String description = descriptionEditText.getText().toString();
        String amountString = amountEditText.getText().toString();

        if (!description.isEmpty() && !amountString.isEmpty()) {
            double amount = Double.parseDouble(amountString);
            transactions.add(new Transaction(description, isIncome ? amount : -amount));

            balance += isIncome ? amount : -amount;
            balanceTextView.setText("Balance: " + balance);

            adapter.notifyDataSetChanged();
            descriptionEditText.setText("");
            amountEditText.setText("");
        }
    }
}
